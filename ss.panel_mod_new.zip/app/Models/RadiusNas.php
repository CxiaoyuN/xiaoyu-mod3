<?php

namespace App\Models;

class RadiusNas extends Model
{
    protected $connection = "radius";
    protected $table = "nas";
}
